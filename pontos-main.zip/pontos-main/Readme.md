# Instalação da aplicação 
# PARA INSTALAÇÃO DA APLICAÇÃO EXECUTE OS COMANDOS ABAIXO:

sudo apt-get updade -y; 
sudo apt-get install git -y;
sudo apt-get install -y libgtk2.0-0 libgtk-3-0 libgbm-dev libnotify-dev libgconf-2-4 libnss3 libxss1 libasound2 libxtst6 xauth xvfb -y; 
git clone https://github.com/cmetrade/pontos; 
chmod +x ~/pontos/shs/install-app.sh
~/pontos/shs/install-app.sh
