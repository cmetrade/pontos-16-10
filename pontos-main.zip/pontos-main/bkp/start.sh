#!/bin/bash
./busca.sh
python3 cme-abertura.py
python3 cme-high.py
python3 cme-low.py
python3 cupom.py
python3 usd-brl.py
python3 dx-alta.py
python3 dx-baixa.py
python3 xau-alta.py
python3 xau-baixa.py
python3 maisum.py
python3 menosum.py
